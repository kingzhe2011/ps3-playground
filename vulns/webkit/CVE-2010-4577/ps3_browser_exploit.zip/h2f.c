/*
 * Convert base address and size to a float number to be used by the exploit.
 * By xerpi
 */

#include <stdio.h>



#ifndef HAS_INT_TYPES

#ifdef HAS_C99
#include <stdint.h>
#else
typedef signed char  int8_t;
typedef signed short int16_t;
typedef signed int   int32_t;
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int   uint32_t;
typedef signed long long   int64_t;
typedef unsigned long long uint64_t;

#define PRIx32   "lx"
#define PRIX32   "lX"

#endif
#endif



#define DEFAULT_SIZE 0xA00000

#define FLOAT_TO_TEST -0.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000086916948407409767516802141034245578305928338506000167136272903009391749587200424

int main(int argc, char *argv[])
{
	if (argc < 2) {
		return -1;
	}

	uint32_t addr, size;

	if (argc == 2) {
		size = DEFAULT_SIZE;
		sscanf(argv[1], "%"PRIx32, &addr);
	} else {
		sscanf(argv[1], "%"PRIx32, &addr);
		sscanf(argv[2], "%"PRIx32, &size);
	}

	uint64_t n = ((uint64_t)addr<<32) | ((size>>1)-1);
	
	uint64_t n2 = ((uint64_t)FLOAT_TO_TEST>>32) | ((size<<1)+1);
	
	printf("address: 0x%08X\n", n2);

	printf("address: 0x%08X\n", addr);
	printf("size:    0x%08X (%.4f MB)\n", size, (size/1024.0)/1024.0);
	printf("[0x%08X - 0x%08X]\n", addr, addr + size);

	double *f = (double *)&n;
	printf("\n%.390lf\n\n", *f);
	return 0;
}
