Any snippets of code can be uploaded here
