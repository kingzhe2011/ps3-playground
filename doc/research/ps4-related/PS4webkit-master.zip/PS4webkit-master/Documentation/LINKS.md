|FreeBSD:
    
    Syscalls:
        FreeBSD Syscalls - http://fxr.watson.org/fxr/source/kern/syscalls.master
        FreeBSD 9.2 Syscalls - http://fxr.watson.org/fxr/source/kern/syscalls.master?v=FREEBSD92
    
    Vulnerability Info:
        http://www.vulnerability-lab.com/
        http://seclists.org/
        http://cxsecurity.com/
        http://www.exploit-db.com/
        http://www.osvdb.org/
        http://www.cvedetails.com/vulnerability-list/vendor_id-6/Freebsd.html
        http://www.cvedetails.com/vulnerability-list/vendor_id-6/cvssscoremin-9/cvssscoremax-/Freebsd.html

|ROP:
    
    Gadgets:
        http://ropshell.com/static/txt/96a2319a40350a4526b7e9be31458cd3.txt.gz
        http://ropshell.com/ropsearch?h=96a2319a40350a4526b7e9be31458cd3&s=stack+pivoting
        http://ropshell.com/ropsearch?h=96a2319a40350a4526b7e9be31458cd3
    
    Framework:
        https://github.com/CTurt/JuSt-ROP
        https://github.com/chaitin/pro

|PSN:
    
    Webkit:
        http://doc.dl.playstation.net/doc/ps4-oss/webkit.html
