bonaire.rai - Bonaire GPU register documentation.
Bypassing_ASLR-DEP_by_Vinay_Katoch.pdf - ASLR/DEP Whitepaper
GCN_Schematics_by_AMD.pdf - IOMMU Whitepaper