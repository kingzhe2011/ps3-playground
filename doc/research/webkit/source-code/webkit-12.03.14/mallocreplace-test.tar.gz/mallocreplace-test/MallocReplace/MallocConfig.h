/*
 * Copyright 2011 Sony Network Entertainment
 * All rights reserved
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND SONY NETWORK ENTERTAINMENT DISCLAIMS
 * ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL SONY NETWORK ENTERTAINMENT
 * BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef __MALLOCCONFIG_H__
#define __MALLOCCONFIG_H__

/*!
 * ENABLE_WRAPPED_API
 * There's currently two ways to hook this library into an executable:
 * 1. using --wrap linker flags, or
 * 2. defining a set of predefined malloc functions
 * Setting this value to 1 means user opted for method 1. Setting this value to
 * 0 means user opted for method 2.
 */
#ifndef ENABLE_WRAPPED_API
#	define ENABLE_WRAPPED_API 0
#endif

/*!
 * ENABLE_MALLOCREPLACE_ARENA
 * If enabled, will set a static arena where all allocations are made.  If set 
 * to 0, this library will act as a pass through and will forward all calls to 
 * malloc to the one provided by the system
 */
#ifndef ENABLE_MALLOCREPLACE_ARENA
#	define ENABLE_MALLOCREPLACE_ARENA 0
#endif

/*!
 * ENABLE_OOM_NOTIFICATION
 * If enabled, the library will invoke the function defined by 
 * MALLOCREPLACE_NOTIFICATION_FUNCTION when an allocation call would have
 * resulted in a failure due to out-of-memory situations
 */
#ifndef ENABLE_OOM_NOTIFICATION
#	define ENABLE_OOM_NOTIFICATION 0
#endif

/*!
 * MALLOCREPLACE_NOTIFICATION_FUNCTION
 * This defines the name of the function the library will call on out-of-memory 
 * situations
 */
#ifndef MALLOCREPLACE_NOTIFICATION_FUNCTION
#	define MALLOCREPLACE_NOTIFICATION_FUNCTION mallocreplace_notify
#endif

#if !ENABLE_WRAPPED_API && !ENABLE_MALLOCREPLACE_ARENA
#error Can't provide unwrapped version of malloc APIs without the use of arena.
#endif

#endif // #ifndef __MALLOCCONFIG_H__
