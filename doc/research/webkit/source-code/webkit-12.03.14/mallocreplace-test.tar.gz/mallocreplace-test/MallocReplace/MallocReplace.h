/*
 * Copyright 2011 Sony Network Entertainment
 * All rights reserved
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND SONY NETWORK ENTERTAINMENT DISCLAIMS
 * ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL SONY NETWORK ENTERTAINMENT
 * BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef __MALLOCREPLACE_H__
#define __MALLOCREPLACE_H__

#include <stdlib.h>

typedef enum {
    MALLOCREPLACE_NOTIFICATION_OOM
} mallocreplace_notification_e;

typedef union {
    struct alloc_info {
        void * address;
        size_t size;
    } alloc_info;
    struct dealloc_info{
        void * address;
        size_t size;
    } dealloc_info;
} mallocreplace_debug_event_info_t;

typedef enum {
    MALLOCREPLACE_NOTIFICATION_ALLOC, // sent on every allocated memory
    MALLOCREPLACE_NOTIFICATION_DEALLOC // sent on every deallocated memory
} mallocreplace_debug_event_e;

typedef void (*mallocreplace_debug_event_listener)(mallocreplace_debug_event_e, mallocreplace_debug_event_info_t *, uintptr_t);

#ifdef __cplusplus
extern "C" {
#endif


	/*!
	 * @brief used to configure heap used by a shared library
	 *
	 * This function sets the size of the heap to be used by the library and must
	 * be called from the main executable before the shared library is loaded.
	 * 
	 * @param heap_size   if heap is set to NULL, the function uses this value 
	 *                    to se the size of the heap to allocated.
	 *                    if heap is non-NULL, this indicates the size of the buffer
	 *                    pointed to by heap.
	 *                    if this value is 0, the heap parameter is ignored and the
	 *                    function uses a default value as the heap size.
	 * @param heap        buffer to be used as heap.  if set to NULL, a buffer
	 *                    will be allocated internally by the function.
	 */
	void mallocreplace_module_set_heap(size_t heap_size, void * heap);

	/*!
	 * @brief returns current heap size and heap set by the caller
	 *
	 * see mallocreplace_module_set_heap()
     *
     * @retval 0 if heap_size and heap is set. <0 otherwise.
	 */
	int mallocreplace_module_get_heap(size_t * heap_size, void ** heap);

    void mallocreplace_module_set_listener(mallocreplace_debug_event_listener, uintptr_t);
    int  mallocreplace_module_get_listener(mallocreplace_debug_event_listener *, uintptr_t *);

	/*!
	 * @brief used to initialize the module support of MallocReplace
	 * 
	 * This function must be called as soon as the application starts
	 */
	int mallocreplace_module_init();

	/*!
	 * @brief cleans up resources used by MallocReplace
	 * 
	 * There isn't a corresponding mallocreplace_init() as there isn't a way for application
	 * to invoke it before global constructors are carried out.  Instead, the library will ensure
	 * mallocreplace_init() is called internally as needed.
	 */
	void mallocreplace_exit();


#ifdef __cplusplus
}
#endif

#endif // #ifndef __MALLOCREPLACE_H__
