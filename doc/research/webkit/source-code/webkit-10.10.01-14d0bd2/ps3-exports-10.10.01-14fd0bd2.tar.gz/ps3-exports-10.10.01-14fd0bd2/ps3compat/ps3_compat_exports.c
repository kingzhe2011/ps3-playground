/*
 * Copyright 2010 Sony Network Entertainment
 * All rights reserved
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND SONY NETWORK ENTERTAINMENT DISCLAIMS
 * ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL SONY NETWORK ENTERTAINMENT
 * BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#if defined(__PS3__)

/* DLLInterface.h is distributed with the PS3 operating system compiler */
#include <DLLInterface.h>

#else

#if defined(__cplusplus)
#define C_CALL extern "C"
#else
#define C_CALL
#endif

#define PLATFORM_DLL_MODULE(name, attr, major, minor)

#define PLATFORM_DLL_START(funcname) \
	C_CALL int platform_dll_start_func(void){return funcname();}

#define PLATFORM_DLL_START_SUCCESS 1
#define PLATFORM_DLL_START_FAILURE 0

#define PLATFORM_DLL_STOP(funcname) \
	C_CALL int platform_dll_stop_func(void){return funcname();}

#define PLATFORM_DLL_STOP_SUCCESS 1
#define PLATFORM_DLL_STOP_FAILURE 0

#define PLATFORM_DLL_LIB(libname, attr)
#define PLATFORM_DLL_LIB_ATTR_REGISTER 0
#define PLATFORM_DLL_LIB_ATTR_OVERRIDE 0
#define PLATFORM_DLL_LIB_ATTR_DEPENDENT_LOAD 0

#define PLATFORM_DLL_EXPORT_FUNC(funcname, libname)
#define PLATFORM_DLL_EXPORT_VAR(variable, libname)
#define PLATFORM_DLL_EXPORT_C_VAR(variable, libname)
#define PLATFORM_DLL_EXPORT_CPP_FUNC(function, libname)
#define PLATFORM_DLL_EXPORT_CLASS(class, libname)
#define PLATFORM_DLL_EXPORT_NAMESPACE(ns, libname)

#endif /* defined(__PS3__) */

#include <bits/atomicity.h>
#include <sys/poll.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <libgen.h>
#include <pthread.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

PLATFORM_DLL_MODULE( ps3_compat, 0, 1, 0 );
PLATFORM_DLL_START( _start );
PLATFORM_DLL_STOP( _stop );

PLATFORM_DLL_LIB( ps3_compat, PLATFORM_DLL_LIB_ATTR_REGISTER | PLATFORM_DLL_LIB_ATTR_DEPENDENT_LOAD );

/* sys/poll.h */
PLATFORM_DLL_EXPORT_FUNC( poll, ps3_compat );

/* sys/select.h */
PLATFORM_DLL_EXPORT_FUNC( select, ps3_compat );

/* sys/socket.h */
PLATFORM_DLL_EXPORT_FUNC( getsockerrno, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( setsockerrno, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( closesocket, ps3_compat );

/* sys/time.h */
PLATFORM_DLL_EXPORT_FUNC( gettimeofday, ps3_compat );

/* libgen.h */
PLATFORM_DLL_EXPORT_FUNC( dirname, ps3_compat );

/* pthread.h */
PLATFORM_DLL_EXPORT_FUNC( pthread_getstack_np, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( pthread_key_create_np, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( pthread_key_delete_np, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( pthread_getspecific_np, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( pthread_setspecific_np, ps3_compat );

/* sched.h */
PLATFORM_DLL_EXPORT_FUNC( sched_yield, ps3_compat );

/* stdio.h */
PLATFORM_DLL_EXPORT_FUNC( vasprintf, ps3_compat );

/* stdlib.h */
PLATFORM_DLL_EXPORT_FUNC( arc4random, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( getenv, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( posix_memalign, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( random, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( srandom, ps3_compat );

/* time.h */
PLATFORM_DLL_EXPORT_FUNC( gmtime_r, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( localtime_r, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( nanosleep, ps3_compat );

/* unistd.h */
PLATFORM_DLL_EXPORT_FUNC( access, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( dup, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( getcwd, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( gethostname, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( getpagesize, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( sleep, ps3_compat );
PLATFORM_DLL_EXPORT_FUNC( usleep, ps3_compat );

int _start(void);
int _stop(void);

int _start(void)
{
    return PLATFORM_DLL_START_SUCCESS;
}

int _stop(void)
{
    return PLATFORM_DLL_STOP_SUCCESS;
}
