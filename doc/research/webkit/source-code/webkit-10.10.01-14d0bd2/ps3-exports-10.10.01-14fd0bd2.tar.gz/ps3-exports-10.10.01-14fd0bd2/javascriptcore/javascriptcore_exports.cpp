/*
 * Copyright 2010 Sony Network Entertainment
 * All rights reserved
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND SONY NETWORK ENTERTAINMENT DISCLAIMS
 * ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL SONY NETWORK ENTERTAINMENT
 * BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#if defined(__PS3__)

/* DLLInterface.h is distributed with the PS3 operating system compiler */
#include <DLLInterface.h>

#else

#if defined(__cplusplus)
#define C_CALL extern "C"
#else
#define C_CALL
#endif

#define PLATFORM_DLL_MODULE(name, attr, major, minor)

#define PLATFORM_DLL_START(funcname) \
	C_CALL int platform_dll_start_func(void){return funcname();}

#define PLATFORM_DLL_START_SUCCESS 1
#define PLATFORM_DLL_START_FAILURE 0

#define PLATFORM_DLL_STOP(funcname) \
	C_CALL int platform_dll_stop_func(void){return funcname();}

#define PLATFORM_DLL_STOP_SUCCESS 1
#define PLATFORM_DLL_STOP_FAILURE 0

#define PLATFORM_DLL_LIB(libname, attr)
#define PLATFORM_DLL_LIB_ATTR_REGISTER 0
#define PLATFORM_DLL_LIB_ATTR_OVERRIDE 0
#define PLATFORM_DLL_LIB_ATTR_DEPENDENT_LOAD 0

#define PLATFORM_DLL_EXPORT_FUNC(funcname, libname)
#define PLATFORM_DLL_EXPORT_VAR(variable, libname)
#define PLATFORM_DLL_EXPORT_C_VAR(variable, libname)
#define PLATFORM_DLL_EXPORT_CPP_FUNC(function, libname)
#define PLATFORM_DLL_EXPORT_CLASS(class, libname)
#define PLATFORM_DLL_EXPORT_NAMESPACE(ns, libname)

#endif /* defined(__PS3__) */

PLATFORM_DLL_MODULE( javascriptcore, 0, 1, 0 );
PLATFORM_DLL_START( StartEntry );
PLATFORM_DLL_STOP( StopEntry );

PLATFORM_DLL_LIB( javascriptcore, PLATFORM_DLL_LIB_ATTR_REGISTER | PLATFORM_DLL_LIB_ATTR_DEPENDENT_LOAD );

PLATFORM_DLL_EXPORT_FUNC( JSCheckScriptSyntax, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSClassCreate, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSClassRelease, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSContextGetGlobalObject, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSEvaluateScript, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSGarbageCollect, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSReportExtraMemoryCost, javascriptcore );

PLATFORM_DLL_EXPORT_FUNC( JSGlobalContextCreateInGroup, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSGlobalContextRelease, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSGlobalContextRetain, javascriptcore );

PLATFORM_DLL_EXPORT_FUNC( JSObjectGetPrivate, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectGetProperty, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectMake, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectSetPrivate, javascriptcore );

PLATFORM_DLL_EXPORT_FUNC( JSPropertyNameAccumulatorAddName, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSPropertyNameArrayGetCount, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSPropertyNameArrayGetNameAtIndex, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSPropertyNameArrayRelease, javascriptcore );

PLATFORM_DLL_EXPORT_FUNC( JSStringCreateWithUTF8CString, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSStringGetMaximumUTF8CStringSize, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSStringGetUTF8CString, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSStringIsEqualToUTF8CString, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSStringRelease, javascriptcore );

PLATFORM_DLL_EXPORT_FUNC( JSValueGetType, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueIsBoolean, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueIsEqual, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueIsInstanceOfConstructor, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueIsNull, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueIsNumber, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueIsObject, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueIsObjectOfClass, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueIsStrictEqual, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueIsString, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueIsUndefined, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueMakeBoolean, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueMakeNull, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueMakeNumber, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueMakeString, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueMakeUndefined, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueProtect, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueToBoolean, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueToNumber, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueToObject, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueToStringCopy, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSValueUnprotect, javascriptcore );

PLATFORM_DLL_EXPORT_FUNC( JSObjectCallAsConstructor, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectCallAsFunction, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectCopyPropertyNames, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectDeleteProperty, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectHasProperty, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectIsFunction, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectGetPropertyAtIndex, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectSetProperty, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectSetPropertyAtIndex, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectSetPrototype, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectMakeArray, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectMakeConstructor, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectMakeDate, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectMakeError, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectMakeFunction, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectMakeFunctionWithCallback, javascriptcore );
PLATFORM_DLL_EXPORT_FUNC( JSObjectMakeRegExp, javascriptcore );

PLATFORM_DLL_EXPORT_FUNC( WTFReportAssertionFailure, javascriptcore );

extern "C" int StartEntry(unsigned int args, void* argp)
{
    (void) args;
    (void) argp;
    return PLATFORM_DLL_START_SUCCESS;
}

extern "C" int StopEntry(unsigned int args, void* argp)
{
    (void) args;
    (void) argp;

    return 0;
}

extern "C" int __cxa_pure_virtual()
{
    return 0;
}
