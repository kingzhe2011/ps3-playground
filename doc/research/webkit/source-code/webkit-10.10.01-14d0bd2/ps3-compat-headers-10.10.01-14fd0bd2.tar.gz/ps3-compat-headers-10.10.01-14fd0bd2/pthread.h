/*
 * Copyright 2010 Sony Network Entertainment
 * All rights reserved
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND SONY NETWORK ENTERTAINMENT DISCLAIMS
 * ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL SONY NETWORK ENTERTAINMENT
 * BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef __PS3_COMPAT_PTHREAD_H__
#define __PS3_COMPAT_PTHREAD_H__

#include <include/pthread.h>

#define pthread_self            sizeof(for) /* DO NOT USE */
#define pthread_once            sizeof(for) /* DO NOT USE */
#define pthread_key_create      sizeof(for) /* DO NOT USE */
#define pthread_key_delete      sizeof(for) /* DO NOT USE */
#define pthread_getspecific     sizeof(for) /* DO NOT USE */
#define pthread_setspecific     sizeof(for) /* DO NOT USE */

#if defined(__cplusplus)
extern "C" {
#endif

int pthread_getstack_np(void **stackaddr, size_t *stacksize);
int pthread_key_create_np(pthread_key_t *key, void (*destructor)(void *));
int pthread_key_delete_np(pthread_key_t key);
void *pthread_getspecific_np(pthread_key_t key);
int pthread_setspecific_np(pthread_key_t key, const void *value);

#if defined(__cplusplus)
}
#endif

#endif /* __PS3_COMPAT_PTHREAD_H__ */
