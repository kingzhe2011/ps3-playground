/*
 * Copyright 2011 Sony Network Entertainment
 * All rights reserved
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND SONY NETWORK ENTERTAINMENT DISCLAIMS
 * ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL SONY NETWORK ENTERTAINMENT
 * BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

/*
 * To replace the functions which are related to the memory management, 
 * you should prepare an object file which includes the definitions of 
 * the functions below.
 * 
 *    void   _malloc_init(void)
 *    void   _malloc_finalize(void)
 *    void * malloc(size_t size)
 *    void   free(void *ptr)
 *    void * calloc(size_t nelem, size_t size)
 *    void * realloc(void *ptr, size_t size)
 *    void * memalign(size_t boundary, size_t size)
 *    void * reallocalign(void *ptr, size_t size, size_t boundary)
 *    int    malloc_stats(struct malloc_managed_size *mmsize)
 *    size_t malloc_usable_size(void *ptr)
 * 
 * The object file (user_malloc.o, for example), which includes the 
 * definitions of the functions above, should be linked to your program 
 * explicitly. The functions above should be defined in one object file. 
 * The object file should not include other definitions of the functions, 
 * and must include all of the above functions.
 * 
 * Notice that these replaced functions are used for not only a user 
 * program but also the functions in the libraries (standard library, for 
 * example).
 */

#include "MallocConfig.h"
#include "MallocReplace.h"
#if ENABLE_MALLOCREPLACE_ARENA
#include <mspace.h>
#endif
#include <stdlib.h>
#include <stdio.h>

/* ---------------------------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------------------------- */

#define __likely(x)   __builtin_expect(!(x) == 0, 1)
#define __unlikely(x) __builtin_expect(!(x) == 0, 0)

#if ENABLE_WRAPPED_API
#   define MALLOCREPLACE_FUNC(x)  __wrap_##x
#else
#   define MALLOCREPLACE_FUNC(x)  x
#endif

#if ENABLE_OOM_NOTIFICATION
#	define MALLOCREPLACE_NOTIFY_OOM() { MALLOCREPLACE_NOTIFICATION_FUNCTION(MALLOCREPLACE_NOTIFICATION_OOM, 0); }
#else
#	define MALLOCREPLACE_NOTIFY_OOM() {}
#endif // #if ENABLE_OOM_NOTIFICATION
int MALLOCREPLACE_NOTIFICATION_FUNCTION(mallocreplace_notification_e, uintptr_t);

#ifdef DEBUG
#   ifdef _PS3_
#       define BREAKPOINT()           { __asm__ volatile ("tw 31,1,1"); }
#       define ASSERT(x)              if (!(x)) { BREAKPOINT(); }
#   else
#       define BREAKPOINT()           { __builtin_trap(); }
#       define ASSERT(x)              if (!(x)) { BREAKPOINT(); }
#  endif
#else
#   define BREAKPOINT()           {}
#   define ASSERT(x)              ((void)(x))
#endif

/* ---------------------------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------------------------- */

extern "C" {
    void * __real_malloc(size_t size);
    void   __real_free(void *ptr);
    void * __real_calloc(size_t nelem, size_t size);
    void * __real_realloc(void *ptr, size_t size);
    void * __real_memalign(size_t boundary, size_t size);
    void * __real_reallocalign(void *ptr, size_t size, size_t boundary);
    int    __real_malloc_stats(struct malloc_managed_size *mmsize);
    size_t __real_malloc_usable_size(void *ptr);
    void   _malloc_finalize();
}

/* ---------------------------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------------------------- */

namespace {

mspace  s_heap_mspace(0);
#define memory_free(ptr)                         ((s_heap_mspace) ? mspace_free(s_heap_mspace, (ptr))                             : __real_free((ptr)))
#define memory_malloc(size)                      ((s_heap_mspace) ? mspace_malloc(s_heap_mspace, (size))                          : __real_malloc((size)))
#define memory_calloc(nelem, size)               ((s_heap_mspace) ? mspace_calloc(s_heap_mspace, (nelem), (size))                 : __real_calloc((nelem), (size)))
#define memory_realloc(ptr, size)                ((s_heap_mspace) ? mspace_realloc(s_heap_mspace, (ptr), (size))                  : __real_realloc((ptr), (size)))
#define memory_memalign(boundary, size)          ((s_heap_mspace) ? mspace_memalign(s_heap_mspace, (boundary), (size))            : __real_memalign((boundary),(size)))
#define memory_reallocalign(ptr, size, boundary) ((s_heap_mspace) ? mspace_reallocalign(s_heap_mspace, (ptr), (size), (boundary)) : __real_reallocalign((ptr), (size), (boundary)))
#define memory_malloc_stats(mmsize)              ((s_heap_mspace) ? mspace_malloc_stats(s_heap_mspace, (mmsize))                  : __real_malloc_stats((mmsize)))
#define memory_malloc_usable_size(ptr)           ((s_heap_mspace) ? mspace_malloc_usable_size((ptr))                              : __real_malloc_usable_size((ptr)))

uint64_t                           s_memory_sentinel(-1); // used for 0-sized allocations
int                                s_initialized(0);
size_t                             s_module_heap_size(0);
void *                             s_module_heap(NULL);
uintptr_t                          s_event_listener_data;
mallocreplace_debug_event_listener s_event_listener;
int                                s_event_listener_installed(mallocreplace_module_get_listener(&s_event_listener, &s_event_listener_data) == 0);

inline size_t get_chunk_size(void * memory) __attribute__((__always_inline__));
inline size_t get_chunk_size(void * memory)
{
    size_t * chunk_ptr(static_cast<size_t*>(memory));
    --chunk_ptr;
    size_t chunk_size((*chunk_ptr) & ~0x3);

    // smallest chunk size is 16
    ASSERT(chunk_size >= 16);
  
    return chunk_size;
}

namespace stats {

size_t s_total_alloc_calls(0);
size_t s_total_free_calls(0);
size_t s_high_watermark(0);
size_t s_heap_usage(0);
size_t s_heap_size(0);

inline void update_high_watermark() __attribute__((__always_inline__));
inline void update_high_watermark()
{
    if (__unlikely(s_high_watermark < s_heap_usage)) {
        s_high_watermark = s_heap_usage;
    }
}

inline void update_heap_usage() __attribute__((__always_inline__));
inline void update_heap_usage(void * memory, bool increment)
{
    size_t chunk_size(get_chunk_size(memory));
    __sync_fetch_and_add(&s_heap_usage, increment ? chunk_size : -chunk_size);
}

inline void initialize(size_t heap_size) __attribute__((__always_inline__));
inline void initialize(size_t heap_size)
{
	s_heap_size         = heap_size;
	s_total_alloc_calls = 0;
	s_total_free_calls  = 0;
	s_high_watermark    = 0;
	s_heap_usage        = 0;
} 

inline void create(void * memory) __attribute__((__always_inline__));
inline void create(void * memory)
{
	if (__likely(memory)) {
		__sync_fetch_and_add(&s_total_alloc_calls, 1);
        stats::update_heap_usage(memory, true);
        stats::update_high_watermark();
	}
}

inline void destroy(void * memory) __attribute__((__always_inline__));
inline void destroy(void * memory)
{
	if (__likely(memory)) {
		__sync_fetch_and_add(&s_total_free_calls, 1);
        stats::update_heap_usage(memory, false);
	}
}


} // namespace stats

inline void ensure_initialized() __attribute__((__always_inline__));
inline void ensure_initialized()
{
    static int s_module_heap_configured(mallocreplace_module_get_heap(&s_module_heap_size, &s_module_heap) == 0);
    if (__unlikely(!s_initialized)) {
        s_initialized = 1;
        
        size_t heap_size(s_module_heap_configured ? s_module_heap_size : 0);
        void * heap(s_module_heap_configured ? s_module_heap : NULL);
        
        if (heap_size && heap) {
            // create the arena
            s_heap_mspace = mspace_create(heap, heap_size);
        }

        stats::initialize(heap_size);

        atexit(_malloc_finalize);
    }
}

inline void ensure_finalized() __attribute((__always_inline__));
inline void ensure_finalized() 
{
    if (s_initialized) {
    // Nitin Mohan: disabled as static/global initialization order and mallocreplace are not playing nice with each other on exit
    // 	s_initialized = 0;

#if (defined(DEBUG) && (DEBUG != 0))
        printf("\n---------------------------------\nmallocreplace stats\n\theap size: %dMB\n\thigh watermark: %d\n\ttotal allocations: %d\n\tleaks: %d (%d bytes)\n",
               stats::s_heap_size / (1024*1024),
               stats::s_high_watermark,
               stats::s_total_alloc_calls,
               stats::s_total_alloc_calls - stats::s_total_free_calls,
               stats::s_heap_usage);
#endif

        // Nitin Mohan: disabled as static/global initialization order and mallocreplace are not playing nice with each other on exit
        // if (s_heap_mspace) {
        //     mspace_destroy(s_heap_mspace);
        // }
	}
}

inline void notify_memory_alloc(void * memory, size_t size) __attribute__((__always_inline__));
inline void notify_memory_alloc(void * memory, size_t size)
{
    if (__unlikely(s_event_listener_installed)) {
        mallocreplace_debug_event_info_t info;
        info.alloc_info.address = memory;
        info.alloc_info.size = get_chunk_size(memory);
        s_event_listener(MALLOCREPLACE_NOTIFICATION_ALLOC, &info, s_event_listener_data);
    }
}

inline void notify_memory_dealloc(void * memory) __attribute__((__always_inline__));
inline void notify_memory_dealloc(void * memory)
{
    if (__unlikely(s_event_listener_installed)) {
        mallocreplace_debug_event_info_t info;
        info.dealloc_info.address = memory;
        info.dealloc_info.size = get_chunk_size(memory);
        s_event_listener(MALLOCREPLACE_NOTIFICATION_DEALLOC, &info, s_event_listener_data);
    }
}

static bool force_initialize() 
{
    ensure_initialized();  
    return true;
}

static volatile bool s_force_initialize = force_initialize();

} // anonymous namespace

/* ---------------------------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------------------------- */

/* 
 * void _malloc_init()
 * Initialize function for malloc series. This function is called at the beginning
 * of the program, before executing `main()' and also all of the global constructors.
 * Notice that there are some limitation below for this function.
 *   - CANNOT access any streams (i.e., no printf(), no fprintf(), etc..).
 *   - CANNOT access any global objects which need the constructor to initialize.
 */
extern "C" void _malloc_init()
{
	ensure_initialized();
}

/*
 * void _malloc_finalize()
 * Finalize function for malloc series. This function is called at the end
 * of the program, after executing `main()' and also all of the global destructors.
 * Notice that there are some limitation below for this function.
 *   - CANNOT access any streams (i.e., no printf(), no fprintf(), etc..).
 *   - CANNOT access any global objects which need the destructor to finalize.
 */
extern "C" void _malloc_finalize()
{
    ensure_finalized();
}

extern "C" void MALLOCREPLACE_FUNC(free)(void * ptr) 
{
	if (__likely((ptr) && (ptr != &s_memory_sentinel))) {
        ensure_initialized();

        notify_memory_dealloc(ptr);
        stats::destroy(ptr);
        memory_free(ptr);
    }

    return;
}

extern "C" void * MALLOCREPLACE_FUNC(malloc)(size_t size) 
{
    if (__likely(size > 0)) {
        ensure_initialized();

        void * retval(memory_malloc(size));
        if (__likely(retval)) {
            notify_memory_alloc(retval, size);
            stats::create(retval);
            return retval;
        }

        MALLOCREPLACE_NOTIFY_OOM();
        return NULL;
    }
    return &s_memory_sentinel;
}

extern "C" void * MALLOCREPLACE_FUNC(calloc)(size_t nelem, size_t size) 
{
    if (__likely((nelem > 0) && (size > 0))) {
        ensure_initialized();

        void * retval(memory_calloc(nelem, size));
        if (__likely(retval)) {
            notify_memory_alloc(retval, nelem * size);
            stats::create(retval);
            return retval;
        }

        MALLOCREPLACE_NOTIFY_OOM();
        return NULL;
    }
    return &s_memory_sentinel;
}

extern "C" void * MALLOCREPLACE_FUNC(realloc)(void * ptr, size_t size) 
{
	ensure_initialized();

	notify_memory_dealloc(ptr);
	stats::destroy(ptr);

    void * retval(memory_realloc(ptr, size));
    if (__likely(retval)) {
        notify_memory_alloc(retval, size);
        stats::create(retval);
        return retval;
    }

	MALLOCREPLACE_NOTIFY_OOM();
    return NULL;
}

extern "C" void * MALLOCREPLACE_FUNC(memalign)(size_t boundary, size_t size) 
{
    if (__likely(size > 0)) {
        ensure_initialized();

        void * retval(memory_memalign(boundary, size));
        if (__likely(retval)) {
            notify_memory_alloc(retval, size);
            stats::create(retval);
            return retval;
        }

        MALLOCREPLACE_NOTIFY_OOM();
        return NULL;
    }
    return &s_memory_sentinel;
}

extern "C" void * MALLOCREPLACE_FUNC(reallocalign)(void * ptr, size_t size, size_t boundary) 
{
	ensure_initialized();

	notify_memory_dealloc(ptr);
	stats::destroy(ptr);

    void * retval(memory_reallocalign(ptr, size, boundary));
    if (__likely(retval)) {
        notify_memory_alloc(retval, size);
        stats::create(retval);
        return retval;
    }

	MALLOCREPLACE_NOTIFY_OOM();
    return NULL;
}

extern "C" int MALLOCREPLACE_FUNC(malloc_stats)(struct malloc_managed_size * mmsize) 
{
	ensure_initialized();
    if ((mmsize != NULL) && 
        (mmsize->max_system_size == 0x11223344) &&
        (mmsize->current_system_size == 0x55667788) &&
        (mmsize->current_inuse_size == 0xbeeffeeb)) {
        mmsize->max_system_size = stats::s_heap_size;
        mmsize->current_system_size = stats::s_heap_size;
        mmsize->current_inuse_size = stats::s_heap_usage;
    }
    return memory_malloc_stats(mmsize);
}

extern "C" size_t MALLOCREPLACE_FUNC(malloc_usable_size)(void * ptr) 
{
	ensure_initialized();
    return memory_malloc_usable_size(ptr);
}
