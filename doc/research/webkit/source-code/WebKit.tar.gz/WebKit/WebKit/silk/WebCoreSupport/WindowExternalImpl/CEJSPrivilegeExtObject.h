///////////////////////////////////////////////////////////////////////////////
// Copyright     2009, 2012 Sony Corporation
// Copyright (C) 2012 Sony Computer Entertainment Inc.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
///////////////////////////////////////////////////////////////////////////////
#ifndef CEJSPrivilegeExtObject_h
#define CEJSPrivilegeExtObject_h

#include "runtime/JSObject.h"
#include "UString.h"
#include "PrototypeFunction.h"
#include "ceuhashtableT.h"
#include "ICEJSExtPropertyDeclarer.h"
#include "ICEJSPrivilegeExtObjectListener.h"
#include "CEComAtomicSupport.h"

///////////////////////////////////////////////////////////////////////////////
// CEJSPrivilegeExtObject
// this is for window.external.foo object as application interface
///////////////////////////////////////////////////////////////////////////////
class JSExternal;
class JSPrivilegeExtObject;
class CEJSPrivilegeExtObject
{
public:
	////////////////////////////////////////////////////////////////
	// operator new, delete, new[] and delete[].
	////////////////////////////////////////////////////////////////
	CEALLOCATORS;

	CEJSPrivilegeExtObject()
	{
		_jsObject = 0;
		_refCount = 0;
	}
	~CEJSPrivilegeExtObject()
	{
		_jsObject = 0;
		CEASSERT(_refCount == 0);
	}
	void _init(JSPrivilegeExtObject* jsObject)
	{
		CEASSERT(jsObject);
		_jsObject = jsObject;
	}

public:
	void AddRef()
	{
		CEComAtomicIncrement(_refCount);
	}

	void Release()
	{
		CEATOMIC refCount = CEComAtomicDecrement(_refCount);
		if (refCount == 0)
		{
			delete this;
		}
	}

private:
	CEATOMIC _refCount;

	///////////////////////////////////
	//  ICEJSExtVariantFactory methods
	///////////////////////////////////
public:
	CEHResult createFromUndefined(ICEJSExtVariant** pVariantOut);
	CEHResult createFromNull(ICEJSExtVariant** pVariantOut);
	CEHResult createFromBoolean(UINT8 booleanValue, ICEJSExtVariant** pVariantOut);
	CEHResult createFromInt32(INT32 int32Value, ICEJSExtVariant** pVariantOut);
	CEHResult createFromNumber(double doubleValue, ICEJSExtVariant** pVariantOut);
	CEHResult createFromString(const UTF16CHAR* pCharArray16, UINT32 numOfChars16, ICEJSExtVariant** pVariantOut);

protected:
	// ICEJSExtVariantFactory vptr
	const void* _variantFactoryVptr;

	/////////////////////////////////////
	//  ICEJSExtPropertyDeclarer methods
	/////////////////////////////////////
public:
	CEHResult declareProperty(INT32 propertyId, const UTF16CHAR* pPropertyName, UINT32 numOfChars16, UINT32 attr);
	CEHResult declareMethod(INT32 propertyId, const UTF16CHAR* pPropertyName, UINT32 numOfChars16, UINT32 attr, UINT32 argCount);

	CEHResult declareChildProperty(INT32 propertyId, const UTF16CHAR* pPropertyName, UINT32 numOfChars16, UINT32 attr);
	CEHResult declareChildMethod(INT32 propertyId, const UTF16CHAR* pPropertyName, UINT32 numOfChars16, UINT32 attr, UINT32 argCount);
protected:
	// ICEJSExtPropertyDeclarer vptr
	const void* _propertyDeclarerVptr;
	// ICEJSExtPropertyParent vptr
	const void* _propertyParentVptr;

private:
	JSPrivilegeExtObject* _jsObject;
public:
	static JSC::JSValue JSC_HOST_CALL windowExternalSystemFunc(
		JSC::ExecState* exec, JSC::JSObject* obj, JSC::JSValue thisValue, const JSC::ArgList& arglist);

};

///////////////////////////////////////////////////////////////////////////////
// JSPrivilegeExtObject
// this is for window.external.foo object
///////////////////////////////////////////////////////////////////////////////
class JSPrivilegeExtObjectPrototype;
class JSExternal;
class CEJSPrivilegeExtObjectGlue;

class JSPrivilegeExtObject : public JSC::JSObject
{
	friend class CEJSPrivilegeExtObject;
public:
	explicit JSPrivilegeExtObject(PassRefPtr<JSC::Structure> structure);
	virtual ~JSPrivilegeExtObject();

	static JSC::JSObject* createPrototype(JSC::ExecState* exec);

	virtual bool getOwnPropertySlot(JSC::ExecState* exec, const JSC::Identifier& propertyName, JSC::PropertySlot& slot);
	virtual void put(JSC::ExecState* exec, const JSC::Identifier& propertyName, JSC::JSValue value, JSC::PutPropertySlot& slot);

	virtual const JSC::ClassInfo* classInfo() const { return &s_info; }
	static const JSC::ClassInfo s_info;

	static PassRefPtr<JSC::Structure> createStructure(JSC::JSValue prototype)
	{
		return JSC::Structure::create(prototype, JSC::TypeInfo(JSC::ObjectType));
	}

	static CEHResult create(JSC::ExecState* exec, INT_PTR objectId, JSPrivilegeExtObject** rObjectOut, JSExternal* owner);

private:
	CEHResult _init(JSC::ExecState* exec, INT_PTR objectId, JSExternal* owner);
	CEHResult _shutdown();

	/////////////////////////////////
	// operations
	/////////////////////////////////
public:
	INT_PTR getObjectId() const { return _member ? _member->_objectId : 0; }

private:
	// User Defined Properties/Methods Implement
	class PropertyKey
	{
	 public:
		PropertyKey(const JSC::Identifier& iName) : _rName(iName) { }
		~PropertyKey() {} // no inherit

		UINT32 getHash() const { return _rName.ustring().rep()->hash(); }
		const JSC::Identifier& getName() const { return _rName; }

	 private:
		const JSC::Identifier _rName;
	};

	class PropertyEntry
	{
		friend class JSPrivilegeExtObject;
	 public:
		PropertyEntry(const JSC::Identifier& iName, INT32 propertyId, UINT32 attr, bool isMethod, UINT32 defaultArgCount, JSPrivilegeExtObject* pOwner)
			: _key(iName), _propertyId(propertyId), _attr(attr), _isMethod(isMethod), _defaultArgCount(defaultArgCount), _pOwner(pOwner)
		{
		}
		// no inherit
		~PropertyEntry() {}

		// callback to application
		CEHResult callbackSetProperty(JSC::ExecState* exec, JSC::JSValue setValue, JSC::JSValue& valueOut);
		CEHResult callbackGetValue(JSC::ExecState* exec, JSC::JSValue& valueOut);
		CEHResult invoke(JSC::ExecState* exec, const JSC::ArgList& arglist, JSC::JSValue& valueOut);

		UINT32 getDefaultArgCount() const { return _defaultArgCount; }
		bool isReadOnly() const { return _attr & CEJSExtPropertyAttr_ReadOnly; }
		bool isMethod() const { return _isMethod; }

		// hash implementation
		const PropertyKey& getKey() const { return _key; }
		bool isEqual(const PropertyKey& key) const { return _key.getName() == key.getName(); }

	 private:
		PropertyKey _key;
		INT32 _propertyId;
		UINT32 _attr;
		bool _isMethod : 1;
		UINT32 _defaultArgCount;
		JSPrivilegeExtObject* _pOwner;
	};
private:
	CEJSPrivilegeExtObjectGlue* getGlueObject()
	{
		return( _member ? _member->_glueObject : 0 );
	}

	// add/get User Defined Properties/Methods.
private:
	CEHResult addUserPropertyEntry(JSC::Identifier& idt, INT32 propertyId, UINT32 attr);
	CEHResult addUserMethodEntry(JSC::ExecState* exec, JSC::Identifier& idt, INT32 propertyId, UINT32 attr, UINT32 argCount);
	CEHResult addUserChildMethodEntry(JSC::ExecState* exec, JSC::Identifier& idt, INT32 propertyId, UINT32 attr, UINT32 argCount);
	bool canGetItemsForName(const JSC::Identifier&, PropertyEntry*& pEntry);
public:
	static CEHResult invokeSystemMethod(JSC::ExecState* exec, const JSC::ArgList& arglist, JSC::JSValue& rValue, INT32 propertyId);
	CEHResult invokeUserMethod(JSC::ExecState* exec, const JSC::Identifier& idt, const JSC::ArgList& arglist, JSC::JSValue& rValue);
	void setPropertyId(INT32 propertyId);
	INT32 getPropertyId();
private:
	// the heap couldn't allocate big class.
	struct _member_def {
		CEJSPrivilegeExtObjectGlue* _glueObject;
		INT_PTR _objectId;
		CEUHashtableT<PropertyEntry, PropertyKey> _propertyHash;
		bool _isDeclared : 1;
	};
	_member_def* _member;
	JSExternal* _owner;
	INT32 _propertyId;
	static CEJSPrivilegeExtObjectGlue* _glueself;
	static JSPrivilegeExtObject* _self;
};


//
// class JSPrivilegeExtObjectPrototype
//
class JSPrivilegeExtObjectPrototype : public JSC::JSObject {
public:
	//static JSC::JSObject* self(JSC::ExecState*);
	virtual const JSC::ClassInfo* classInfo() const { return &s_info; }
	static const JSC::ClassInfo s_info;
	virtual bool getOwnPropertySlot(JSC::ExecState*, const JSC::Identifier&, JSC::PropertySlot&);
	static PassRefPtr<JSC::Structure> createStructure(JSC::JSValue prototype)
	{
		return JSC::Structure::create(prototype, JSC::TypeInfo(JSC::ObjectType));
	}
	JSPrivilegeExtObjectPrototype(PassRefPtr<JSC::Structure> structure) : JSC::JSObject(structure) { }
};


///////////////////////////////////////////////////////////////////////////////
// CEJSPrivilegeExtObjectCollection
///////////////////////////////////////////////////////////////////////////////
class CEJSPrivilegeExtObjectCollection
{
public:
	CEALLOCATORS;

	CEJSPrivilegeExtObjectCollection(JSExternal* owner);
	~CEJSPrivilegeExtObjectCollection();

	CEHResult init();
	CEHResult shutdown();

	/////////////////////////////////
	// operation
	/////////////////////////////////
public:
	CEHResult hasPrivilegeExtObject(JSC::ExecState* exec, const JSC::Identifier& iPropName, bool& isReadOnly);
	CEHResult getPrivilegeExtObject(JSC::ExecState* exec, const JSC::Identifier& iPropName, JSC::JSValue& valueOut);

private:
	class PrivilegeExtObjectKey
	{
	 public:
		CEALLOCATORS;

		PrivilegeExtObjectKey(INT32 classId) : _classId(classId) {}
		~PrivilegeExtObjectKey() {} // no inherit

		UINT32 getHash() const { return static_cast<UINT32>(_classId); }
		INT32 getClassId() const { return _classId; }

	 private:
		INT32 _classId;
	};

	class PrivilegeExtObjectEntry
	{
	 public:
		CEALLOCATORS;

		PrivilegeExtObjectEntry(INT32 classId) : _key(classId), _authStatus(CEJSAuthStatus_UnauthorizedTemporarily), _rObject(0) {}
		~PrivilegeExtObjectEntry() {} // no inherit

		CEHResult getObject(JSC::ExecState* exec, JSExternal* owner, JSC::JSValue& valueOut);

		// hash implementation
		const PrivilegeExtObjectKey& getKey() const { return _key; }
		bool isEqual(const PrivilegeExtObjectKey& key) const { return _key.getClassId() == key.getClassId(); }

	 private:
		PrivilegeExtObjectKey _key;
		CEJSAuthStatus _authStatus;
		JSPrivilegeExtObject* _rObject;
	};

private:
	//CEHResult _hasPrivilegeExtObject(const JSC::Identifier& iPropName, bool& isReadOnly);
	//CEHResult _getPrivilegeExtObject(const JSC::Identifier& iPropName, JSC::JSValue& valueOut);

private:
	JSExternal* _owner;
	CEUHashtableT<PrivilegeExtObjectEntry, PrivilegeExtObjectKey> _privilegeExtObjectHash;
};

#endif
