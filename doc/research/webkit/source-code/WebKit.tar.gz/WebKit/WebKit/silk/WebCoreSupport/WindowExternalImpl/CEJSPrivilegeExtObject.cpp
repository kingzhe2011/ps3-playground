///////////////////////////////////////////////////////////////////////////////
// Copyright     2009, 2012 Sony Corporation
// Copyright (C) 2012 Sony Computer Entertainment Inc.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
///////////////////////////////////////////////////////////////////////////////
#include "WebKitSilkPrefix.h"
#include "JSDOMWindow.h"
#include "CEJSExternal.h"
#include "CEJSPrivilegeExtObject.h"

#include <runtime/JSLock.h>
#include "UString.h"
#include "PrototypeFunction.h"
#include "runtime/JSValue.h"
#include "runtime/FunctionConstructor.h"
#include "../JSUtilityFunc.h"
#include "JSDOMBinding.h"
#include <runtime/JSGlobalObject.h>
#include <runtime/ObjectPrototype.h>

#include "CEJSPrivilegeExtObject.h"
#include "CEJSExtVariant.h"
#include "CEJSExtVariantGlue.h"
#include "CEJSPrivilegeExtObjectDeclaration.h"
#include "CEJSPrivilegeExtObjectGlue.h"

#include "../CEHtmlCredentialBase.h"
#include "CEHtmlCredentialGlue.h"

// callback from JS engine
static JSC::JSValue JSC_HOST_CALL _invokeMethod(
	JSC::ExecState* exec, JSC::JSObject* obj, JSC::JSValue thisValue, const JSC::ArgList& arglist);

JSPrivilegeExtObject* JSPrivilegeExtObject::_self = NULL;
//////////////////////////////////////////////////////////////////////////////
// JSPrivilegeExtObject
//////////////////////////////////////////////////////////////////////////////
CEHResult JSPrivilegeExtObject::create(
	JSC::ExecState* exec, INT_PTR objectId, JSPrivilegeExtObject** rObjectOut, JSExternal* owner)
{
	CEHResult hr = CE_S_OK;
	*rObjectOut = new (exec) JSPrivilegeExtObject(
		JSPrivilegeExtObject::createStructure(JSPrivilegeExtObject::createPrototype(exec)));

	if( *rObjectOut )
	{
		CEComICEHtmlCredentialRef cred;
		hr = owner->getCredential(cred);
		if (CESucceeded(hr) && cred && cred.object())
		{
			hr = reinterpret_cast<CEHtmlCredentialBase*>(CEHtmlCredentialGlue::toSubstance(cred.object()))->saveCurrentCertificate();
		}
		if (CESucceeded(hr))
		{
			JSPrivilegeExtObject::_self = *rObjectOut;
			hr = (*rObjectOut)->_init(exec, objectId, owner);
			CEASSERT(hr == CE_S_OK && "TODO why error, delete rObjectOut.");
		}
	}
	else
	{
		hr = CE_SILK_ERR_MEMERR;
	}
	return hr;
}

JSPrivilegeExtObject::JSPrivilegeExtObject(
	PassRefPtr<JSC::Structure> structure) 
	: JSC::JSObject(structure), _member(0)
{
}

JSPrivilegeExtObject::~JSPrivilegeExtObject()
{
	_shutdown();
}

CEJSPrivilegeExtObjectGlue* JSPrivilegeExtObject::_glueself = NULL;

CEHResult JSPrivilegeExtObject::_init(JSC::ExecState* exec, INT_PTR objectId, JSExternal* owner)
{
	CEHResult hr = CE_SILK_ERR_MEMERR;
	_member = new _member_def();
	if( _member )
	{
		_owner = owner;
		_member->_glueObject = new CEJSPrivilegeExtObjectGlue();
		if( _member->_glueObject )
		{
			JSPrivilegeExtObject::_glueself = _member->_glueObject;
			_member->_glueObject->_init(this);
			_member->_glueObject->AddRef();
		}
		else
		{
			return(CE_SILK_ERR_MEMERR);
		}
		_member->_objectId = objectId;
		_member->_isDeclared = false;
		hr = _member->_propertyHash.init(CEComGetAllocatorRec(), 8);

		if(CESucceeded(hr))
		{
			_member->_isDeclared = true;
			// declare properties at application
			if ( true == owner->declareObjectForParent() )
			{
				CEJSExternalAppCallback::declarePropertyOfPrivilegeExtObjWithParent(exec, _member->_objectId,
											  CEJSPrivilegeExtObjectGlue::toICEJSExtPropertyParent(_member->_glueObject),
											  CEJSPrivilegeExtObjectGlue::toICEJSExtPropertyDeclarer(_member->_glueObject));
			}
			else
			{
				CEJSExternalAppCallback::declarePropertyOfPrivilegeExtObj(exec,
											  _member->_objectId,
											  CEJSPrivilegeExtObjectGlue::toICEJSExtPropertyDeclarer(_member->_glueObject));
			}
		}
	}
	return hr;
}

CEHResult JSPrivilegeExtObject::_shutdown()
{
	CEHResult hr = CE_S_OK;

	if( _member )
	{
		_member->_glueObject->Release();
		_member->_glueObject = 0;

		CEUHashtableT<PropertyEntry, PropertyKey>::Iterator iter(_member->_propertyHash);
		PropertyEntry* pEntry;
		while ((pEntry = iter.nextElement()))
		{
			delete pEntry;
		}
		_member->_propertyHash.shutdown();
		
		CEJSExternalAppCallback::finalizeObjectIdOfPrivilegeExtObj(_member->_objectId);
	}
	delete _member;
	_member = 0;

	if (JSPrivilegeExtObject::_glueself) JSPrivilegeExtObject::_glueself = NULL;
	if (JSPrivilegeExtObject::_self) JSPrivilegeExtObject::_self = NULL;

	return hr;
}

const JSC::ClassInfo JSPrivilegeExtObject::s_info = {"JSPrivilegeExtObject", 0, 0, 0};

JSC::JSObject* JSPrivilegeExtObject::createPrototype(JSC::ExecState* exec)
{
	return new (exec) JSPrivilegeExtObjectPrototype(JSPrivilegeExtObjectPrototype::createStructure(exec->lexicalGlobalObject()->objectPrototype()));
}

bool JSPrivilegeExtObject::getOwnPropertySlot(
	JSC::ExecState* exec, const JSC::Identifier& propertyName, JSC::PropertySlot& slot)
{
	CEComDebugPrintf("JSPrivilegeExtObject::getOwnPropertySlot: called. name=%*s\n", propertyName.size(), propertyName.data());

	CEHResult hr = CE_S_OK;
	bool ret = false;
	PropertyEntry* pEntry = NULL;
	JSC::JSValue localVal = getDirect(propertyName);
	bool bNeedCallback = canGetItemsForName(propertyName, pEntry);
	if ( false == bNeedCallback )
	{
		// return local.
		if( localVal != JSC::JSValue() )
		{
			slot.setValue(localVal);
			ret = true;
		}
	}
	else if( pEntry && pEntry->isMethod() && localVal.isObject() )
	{
		// there is method in local.
		slot.setValue(localVal);
		ret = true;
	}
	else
	{
		// check local and get from callbacks if need.
		if( localVal != JSC::JSValue() )
		{
			// already have. but is it need update?
			if( !(pEntry->_attr & CEJSExtPropertyAttr_Const) )
			{
				CEJSIsDirtyStatus status;
				hr = CEJSExternalAppCallback::isDirtyPropertyOfPrivilegeExtObj(exec, getObjectId(), pEntry->_propertyId, &status);
				if (CESucceeded(hr))
				{
					if( status == CEJSIsDirtyStatus_Dirty )
					{
						// value is dirty. get from callbacks again.
						localVal = JSC::JSValue();
					}
					else
					{
						// not dirty. return localVal
						slot.setValue(localVal);
						ret = true;
					}
				}
			}
		}
		if( localVal == JSC::JSValue() )
		{
			// get from callbacks
			hr = pEntry->callbackGetValue(exec, localVal);
			if(CESucceeded(hr))
			{
				CEComDebugPrintf("  Found it. %hs=[%*s]\n", propertyName.ascii(), localVal.toString(exec).size(), localVal.toString(exec).data());
				// save local
				putDirect(propertyName, localVal);
				slot.setValue(localVal);
				ret = true;
			}
		}
		else
		{
			// return local value
			slot.setValue(localVal);
			ret = true;
		}
	}

	if( ret == true && localVal == JSC::JSValue() )
	{
		CEASSERT(0 && "why?");
		ret = false;
	}
	return(ret);
}

bool JSPrivilegeExtObject::canGetItemsForName(
	const JSC::Identifier& propertyName, PropertyEntry*& pEntry)
{
	if( _member == 0 )
	{
		return(false);
	}

	CEASSERT(_member->_isDeclared);

	PropertyKey key(propertyName);
	pEntry = NULL;
	if (_member->_propertyHash.find(key, pEntry))
	{
		return(true);
	}
	else
	{
		return(false);
	}
}

void JSPrivilegeExtObject::put(
	JSC::ExecState* exec, const JSC::Identifier& propertyName, JSC::JSValue value, JSC::PutPropertySlot& slot)
{
	JSC::JSValue val = value; // do not delete
	PropertyEntry* pEntry = NULL;
	if ( false == canGetItemsForName(propertyName, pEntry) )
	{
		CEComDebugPrintf("JSPrivilegeExtObject::put: to object, name=%*s, value=%*s\n", 
			propertyName.size(), propertyName.data(),  val.toString(exec).size(), val.toString(exec).data());

		// put to object
		putDirect(propertyName, val);
	}
	else
	{
		CEComDebugPrintf("JSPrivilegeExtObject::put: set value, name=%*s, value=%*s\n", 
			propertyName.size(), propertyName.data(),  val.toString(exec).size(), val.toString(exec).data());

		CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
		CEASSERT(pEntry);
		if( _member && pEntry )
		{
			if (pEntry->isReadOnly())
			{
				hr = CE_S_OK;
			}
			else
			{
				JSC::JSValue valueOut;
				hr = pEntry->callbackSetProperty(exec, val, valueOut);
				if(CESucceeded(hr))
				{
					// set to local property
					putDirect(propertyName, valueOut);
				}
			}
		}
	}
	return;
}

CEHResult JSPrivilegeExtObject::addUserPropertyEntry(
	JSC::Identifier& idt, INT32 propertyId, UINT32 attr)
{
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	if( _member )
	{
		PropertyEntry* pEntry = NULL;
		if( false == canGetItemsForName(idt, pEntry) )
		{
			pEntry = new PropertyEntry(idt, propertyId, attr, false, 0, this);
			if (pEntry)
			{
				hr = _member->_propertyHash.insert(pEntry);
			}
			else
			{
				hr = CE_SILK_ERR_MEMERR;
			}
		}
		else
		{
			hr = CE_SILK_ERR_OPERATION_FAILED;
		}
	}
	return hr;
}

CEHResult JSPrivilegeExtObject::addUserMethodEntry(
	JSC::ExecState* exec, JSC::Identifier& idt, INT32 propertyId, UINT32 attr, UINT32 argCount)
{
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	if ( _member )
	{
		PropertyEntry* pEntry = NULL;
		if( false == canGetItemsForName(idt, pEntry) )
		{
			pEntry = new PropertyEntry(idt, propertyId, attr, true, argCount, this);
			if (pEntry)
			{
				hr = _member->_propertyHash.insert(pEntry);
			}
			else
			{
				hr = CE_SILK_ERR_MEMERR;
			}
		}
		else
		{
			hr = CE_SILK_ERR_OPERATION_FAILED;
		}

		//
		// add to JS object
		// this is to call method directory.
		JSC::PrototypeFunction* propFunc = new (exec) JSC::PrototypeFunction(exec, 0, idt, _invokeMethod);
		putDirectFunction(exec, propFunc, JSC::DontEnum | JSC::ReadOnly | JSC::DontDelete);
	}
	return hr;
}

CEHResult JSPrivilegeExtObject::addUserChildMethodEntry(
	JSC::ExecState* exec, JSC::Identifier& idt, INT32 propertyId, UINT32 attr, UINT32 argCount)
{
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	if ( _member )
	{
		PropertyEntry* pEntry = NULL;
		if( false == canGetItemsForName(idt, pEntry) )
		{
			pEntry = new PropertyEntry(idt, propertyId, attr, true, argCount, this);
			if (pEntry)
			{
				hr = _member->_propertyHash.insert(pEntry);
			}
			else
			{
				hr = CE_SILK_ERR_MEMERR;
			}
		}
		else
		{
			hr = CE_SILK_ERR_OPERATION_FAILED;
		}
	}
	return hr;
}

CEHResult JSPrivilegeExtObject::invokeUserMethod(
	JSC::ExecState* exec, const JSC::Identifier& idt, const JSC::ArgList& arglist, JSC::JSValue& rValue)
{
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	if( _member )
	{
		PropertyKey key(idt);
		PropertyEntry* pEntry = NULL;
		if (_member->_propertyHash.find(key, pEntry))
		{
			hr = pEntry->invoke(exec, arglist, rValue);
			return hr;
		}
	}
	return hr;
}

CEHResult JSPrivilegeExtObject::invokeSystemMethod(
	JSC::ExecState* exec, const JSC::ArgList& arglist, JSC::JSValue& rValue, INT32 propertyId)
{
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	UINT32 argCount = arglist.size();

	ICEJSExtVariant** pArgValues = CENEW_ARRAY(ICEJSExtVariant*, argCount);
	if (pArgValues)
	{
		hr = CE_S_OK;
		for (UINT32 i = 0; i < argCount; ++i)
		{
			pArgValues[i] = 0;
			if (CESucceeded(hr))
			{
				CEJSExtVariant* pVariant;
				JSC::JSValue val = arglist.at(i);
				hr = CEJSExtVariant::createFromPropertyValue(exec, &val, &pVariant);
				if (CESucceeded(hr))
				{
					pVariant->AddRef();
					pArgValues[i] = CEJSExtVariantGlue::toICEJSExtVariant(pVariant);
				}
			}
		}

		if (CESucceeded(hr))
		{
			ICEJSExtVariant* iJSExtVariant = 0;
			hr = CEJSExternalAppCallback::invokeMethodOfPrivilegeExtObj(
				exec, JSPrivilegeExtObject::_self->_member->_objectId, propertyId, pArgValues, argCount,
				CEJSPrivilegeExtObjectGlue::toICEJSExtVariantFactory(JSPrivilegeExtObject::_glueself), &iJSExtVariant);
			if (CESucceeded(hr))
			{
				if (iJSExtVariant)
				{
					CEComICEJSExtVariantRef rJSExtVariant = iJSExtVariant;
					rValue = CEJSExtVariantGlue::toSubstance(iJSExtVariant)->getPropertyValue();
				}
				else
				{
					rValue = JSC::jsUndefined();
				}
			}
		}
		for (UINT32 i = 0; i < argCount; ++i)
		{
			if (pArgValues[i])
			{
				CEJSExtVariantGlue::toSubstance(pArgValues[i])->Release();
			}
		}
		CEDELETE_ARRAY(pArgValues);
	}
	else
	{
		hr = CE_SILK_ERR_MEMERR;
	}
	return hr;
}

void JSPrivilegeExtObject::setPropertyId(INT32 propertyId)
{ 
	if (_owner)
		_owner->setPropertyId(propertyId);
}

INT32 JSPrivilegeExtObject::getPropertyId()
{
	if (_owner)
		return _owner->getPropertyId();

	return 0;
}

///////////////////////////////////////////////////////////////////////////
// implement external prototype
///////////////////////////////////////////////////////////////////////////
const JSC::ClassInfo JSPrivilegeExtObjectPrototype::s_info = { "JSPrivilegeExtObjectPrototype", 0, 0, 0 };

bool JSPrivilegeExtObjectPrototype::getOwnPropertySlot(JSC::ExecState* exec, const JSC::Identifier& propertyName, JSC::PropertySlot& slot)
{
	//return WebCore::getStaticFunctionSlot<JSC::JSObject>(exec, 0, this, propertyName, slot);
	// always false.
	return(false);
}

CEHResult JSPrivilegeExtObject::PropertyEntry::callbackSetProperty(
	JSC::ExecState* exec, JSC::JSValue setValue, JSC::JSValue& valueOut)
{
	CEJSExtVariant* pVariant;
	valueOut = JSC::JSValue();
	CEHResult hr = CEJSExtVariant::createFromPropertyValue(exec, &setValue, &pVariant);
	if (CESucceeded(hr))
	{
		// callback
		CEComICEJSExtVariantRef rJSExtVariantIn = CEJSExtVariantGlue::toICEJSExtVariant(pVariant);
		ICEJSExtVariant* iJSExtVariantOut;
		hr = CEJSExternalAppCallback::setPropertyOfPrivilegeExtObj(exec, _pOwner->getObjectId(), _propertyId, rJSExtVariantIn.object(),
					CEJSPrivilegeExtObjectGlue::toICEJSExtVariantFactory(_pOwner->getGlueObject()), &iJSExtVariantOut);
		if (CESucceeded(hr))
		{
			if (iJSExtVariantOut)
			{
				// get callback func returned value.
				CEComICEJSExtVariantRef rJSExtVariantOut = iJSExtVariantOut;
				valueOut = CEJSExtVariantGlue::toSubstance(rJSExtVariantOut)->getPropertyValue();
			}
		}
	}
    return hr;
}

CEHResult JSPrivilegeExtObject::PropertyEntry::callbackGetValue(
	JSC::ExecState* exec, JSC::JSValue& valueOut)
{
	CEHResult hr = CE_S_OK;

	valueOut = JSC::JSValue();
	if( _pOwner == 0 || _pOwner->getGlueObject() == 0 )
	{
		CEASSERT(0 && "why?");
		return(CE_SILK_ERR_OPERATION_FAILED);
	}

	// get property
	ICEJSExtVariant* iJSExtVariant = 0;
	hr = CEJSExternalAppCallback::getPropertyOfPrivilegeExtObj(exec, _pOwner->getObjectId(), _propertyId,
			CEJSPrivilegeExtObjectGlue::toICEJSExtVariantFactory(_pOwner->getGlueObject()), &iJSExtVariant);
	if (CESucceeded(hr))
	{
		if (iJSExtVariant)
		{
			CEComICEJSExtVariantRef rJSExtVariant = iJSExtVariant;
			valueOut = CEJSExtVariantGlue::toSubstance(iJSExtVariant)->getPropertyValue();
		}
		else
		{
			hr = CE_SILK_ERR_OPERATION_FAILED;
		}
	}
    return hr;
}

static JSC::JSValue JSC_HOST_CALL _invokeMethod(
	JSC::ExecState* exec, JSC::JSObject* obj, JSC::JSValue thisValue, const JSC::ArgList& arglist)
{
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	JSPrivilegeExtObject* thisObj = static_cast<JSPrivilegeExtObject*>(thisValue.toObject(exec));

	JSC::PrototypeFunction* funcObj = static_cast<JSC::PrototypeFunction*>(obj);
	JSC::Identifier methodName(exec, funcObj->name(&exec->globalData()));

	CEComDebugPrintf("CEJSPrivilegeExtObject.cpp:_invokeMethod: method name=%*s\n", methodName.size(), methodName.data());

	JSC::JSValue retValue;
	hr = thisObj->invokeUserMethod(exec, methodName, arglist, retValue);

	return(retValue);
}

CEHResult JSPrivilegeExtObject::PropertyEntry::invoke(
	JSC::ExecState* exec, const JSC::ArgList& arglist, JSC::JSValue& valueOut)
{
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	UINT32 argCount = arglist.size();

	ICEJSExtVariant** pArgValues = CENEW_ARRAY(ICEJSExtVariant*, argCount);
	if (pArgValues)
	{
		hr = CE_S_OK;
		for (UINT32 i = 0; i < argCount; ++i)
		{
			pArgValues[i] = 0;
			if (CESucceeded(hr))
			{
				CEJSExtVariant* pVariant;
				JSC::JSValue val = arglist.at(i);
				hr = CEJSExtVariant::createFromPropertyValue(exec, &val, &pVariant);
				if (CESucceeded(hr))
				{
					pVariant->AddRef();
					pArgValues[i] = CEJSExtVariantGlue::toICEJSExtVariant(pVariant);
				}
			}
		}

		if (CESucceeded(hr))
		{
			ICEJSExtVariant* iJSExtVariant = 0;
			hr = CEJSExternalAppCallback::invokeMethodOfPrivilegeExtObj(
					exec, _pOwner->getObjectId(), _propertyId, pArgValues, argCount,
					CEJSPrivilegeExtObjectGlue::toICEJSExtVariantFactory(_pOwner->getGlueObject()), &iJSExtVariant);
			if (CESucceeded(hr))
			{
				if (iJSExtVariant)
				{
					CEComICEJSExtVariantRef rJSExtVariant = iJSExtVariant;
					valueOut = CEJSExtVariantGlue::toSubstance(iJSExtVariant)->getPropertyValue();
				}
				else
				{
					valueOut = JSC::jsUndefined();
				}
			}
		}
		for (UINT32 i = 0; i < argCount; ++i)
		{
			if (pArgValues[i])
			{
				CEJSExtVariantGlue::toSubstance(pArgValues[i])->Release();
			}
		}
		CEDELETE_ARRAY(pArgValues);
	}
	else
	{
		hr = CE_SILK_ERR_MEMERR;
	}
    return hr;
}


///////////////////////////////////////////////////////////////////////////////
// CEJSPrivilegeExtObject
// this is for window.external.foo object as application interface
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////
//  ICEJSExtVariantFactory methods
///////////////////////////////////
CEHResult CEJSPrivilegeExtObject::createFromUndefined(ICEJSExtVariant** pVariantOut)
{
	CEJSExtVariant* pVariant;
	CEHResult hr = CEJSExtVariant::createFromUndefined(CEJSExternalAppCallback::getExecState(), &pVariant);
	if (CESucceeded(hr))
	{
		*pVariantOut = CEJSExtVariantGlue::toICEJSExtVariant(pVariant);
	}
	return hr;
}

CEHResult CEJSPrivilegeExtObject::createFromNull(ICEJSExtVariant** pVariantOut)
{
	CEJSExtVariant* pVariant;
	CEHResult hr = CEJSExtVariant::createFromNull(CEJSExternalAppCallback::getExecState(), &pVariant);
	if (CESucceeded(hr))
	{
		*pVariantOut = CEJSExtVariantGlue::toICEJSExtVariant(pVariant);
	}
	return hr;
}

CEHResult CEJSPrivilegeExtObject::createFromBoolean(UINT8 booleanValue, ICEJSExtVariant** pVariantOut)
{
	CEJSExtVariant* pVariant;
	CEHResult hr = CEJSExtVariant::createFromBoolean(CEJSExternalAppCallback::getExecState(), booleanValue, &pVariant);
	if (CESucceeded(hr))
	{
		*pVariantOut = CEJSExtVariantGlue::toICEJSExtVariant(pVariant);
	}
	return hr;
}

CEHResult CEJSPrivilegeExtObject::createFromInt32(INT32 int32Value, ICEJSExtVariant** pVariantOut)
{
	CEJSExtVariant* pVariant;
	CEHResult hr = CEJSExtVariant::createFromInt32(CEJSExternalAppCallback::getExecState(), int32Value, &pVariant);
	if (CESucceeded(hr))
	{
		*pVariantOut = CEJSExtVariantGlue::toICEJSExtVariant(pVariant);
	}
	return hr;
}

CEHResult CEJSPrivilegeExtObject::createFromNumber(double doubleValue, ICEJSExtVariant** pVariantOut)
{
	CEJSExtVariant* pVariant;
	CEHResult hr = CEJSExtVariant::createFromNumber(CEJSExternalAppCallback::getExecState(), doubleValue, &pVariant);
	if (CESucceeded(hr))
	{
		*pVariantOut = CEJSExtVariantGlue::toICEJSExtVariant(pVariant);
	}
	return hr;
}

CEHResult CEJSPrivilegeExtObject::createFromString(const UTF16CHAR* pCharArray16, UINT32 numOfChars16, ICEJSExtVariant** pVariantOut)
{
	CEJSExtVariant* pVariant;
	CEHResult hr = CEJSExtVariant::createFromString(CEJSExternalAppCallback::getExecState(), pCharArray16, numOfChars16, &pVariant);
	if (CESucceeded(hr))
	{
		*pVariantOut = CEJSExtVariantGlue::toICEJSExtVariant(pVariant);
	}
	return hr;
}

/////////////////////////////////////
//  ICEJSExtPropertyDeclarer methods
/////////////////////////////////////
CEHResult CEJSPrivilegeExtObject::declareProperty(
	INT32 propertyId, const UTF16CHAR* pPropertyName, UINT32 numOfChars16, UINT32 attr)
{
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	if ( _jsObject && pPropertyName && numOfChars16 > 0)
	{
		JSC::Identifier symbol = JSC::Identifier(CEJSExternalAppCallback::getExecState(), reinterpret_cast<const UChar*>(pPropertyName), numOfChars16);
		hr = _jsObject->addUserPropertyEntry(symbol, propertyId, attr);
	}
	return hr;
}

CEHResult CEJSPrivilegeExtObject::declareMethod(INT32 propertyId, const UTF16CHAR* pPropertyName, UINT32 numOfChars16, UINT32 attr, UINT32 argCount)
{
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	if ( _jsObject && pPropertyName && numOfChars16 > 0)
	{
		JSC::Identifier symbol = JSC::Identifier(CEJSExternalAppCallback::getExecState(), reinterpret_cast<const UChar*>(pPropertyName), numOfChars16);
		hr = _jsObject->addUserMethodEntry(CEJSExternalAppCallback::getExecState(), symbol, propertyId, attr, argCount);
	}
	return hr;
}

/////////////////////////////////////
//  ICEJSExtPropertyParent methods
/////////////////////////////////////
CEHResult CEJSPrivilegeExtObject::declareChildProperty(
	INT32 propertyId, const UTF16CHAR* pPropertyName, UINT32 numOfChars16, UINT32 attr)
{
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	if ( _jsObject && pPropertyName && numOfChars16 > 0)
	{
		JSC::Identifier symbol = JSC::Identifier(CEJSExternalAppCallback::getExecState(), reinterpret_cast<const UChar*>(pPropertyName), numOfChars16);
		hr = _jsObject->addUserPropertyEntry(symbol, propertyId, attr);
		if (CESucceeded(hr))
		{
			_jsObject->setPropertyId(propertyId);
		}
	}
	return hr;
}

CEHResult CEJSPrivilegeExtObject::declareChildMethod(INT32 propertyId, const UTF16CHAR* pPropertyName, UINT32 numOfChars16, UINT32 attr, UINT32 argCount)
{
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	if ( _jsObject && pPropertyName && numOfChars16 > 0)
	{
		JSC::Identifier symbol = JSC::Identifier(CEJSExternalAppCallback::getExecState(), reinterpret_cast<const UChar*>(pPropertyName), numOfChars16);
		hr = _jsObject->addUserChildMethodEntry(CEJSExternalAppCallback::getExecState(), symbol, propertyId, attr, argCount);
		if (CESucceeded(hr))
		{
			_jsObject->setPropertyId(propertyId);
		}
	}
	return hr;
}

///////////////////////////////////////////////////////////////////////////////
// CEJSPrivilegeExtObjectCollection
///////////////////////////////////////////////////////////////////////////////
CEJSPrivilegeExtObjectCollection::CEJSPrivilegeExtObjectCollection(JSExternal* owner)
{
	_owner = owner;
}

CEJSPrivilegeExtObjectCollection::~CEJSPrivilegeExtObjectCollection()
{
	shutdown();
}

CEHResult CEJSPrivilegeExtObjectCollection::init()
{
	CEHResult hr = _privilegeExtObjectHash.init(CEComGetAllocatorRec(), 8);
	return hr;
}

CEHResult CEJSPrivilegeExtObjectCollection::shutdown()
{
	//CEASSERT(_isShutdownCompleted == false);
	CEHResult hr = CE_S_OK;
	CEUHashtableT<PrivilegeExtObjectEntry, PrivilegeExtObjectKey>::Iterator iter(_privilegeExtObjectHash);
	PrivilegeExtObjectEntry* pEntry;
	while ((pEntry = iter.nextElement()))
	{
		delete pEntry;
	}
	_privilegeExtObjectHash.shutdown();
	return hr;
}

////////////////////////////
// operations 
////////////////////////////
CEHResult CEJSPrivilegeExtObjectCollection::hasPrivilegeExtObject(
	JSC::ExecState* exec, const JSC::Identifier& iPropName, bool& isReadOnly)
{
    isReadOnly = false;
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	CEJSPrivilegeExtObjectDeclaration* declaration = 0;
	if( !_owner )
	{
		return(CE_SILK_ERR_OPERATION_FAILED);
	}

	JSC::UString propStr = iPropName.ustring();
	if ( propStr == JSC::UString("system") )
	{
		_owner->useDeclareObjectForParent();
		_owner->clearOldDeclaredObject();
	}
	hr = _owner->getJSPrivilegeExtObjectDeclaration(exec, &declaration);
	if (CESucceeded(hr) && declaration)
	{
		INT32 classId;
		UINT32 attr;
		hr = declaration->isDeclared(iPropName, &classId, &attr);
		if (CESucceeded(hr))
		{
			isReadOnly = attr & CEJSPrivilegeExtObjectAttr_ReadOnly;
		}
	}
    return hr;
}

CEHResult CEJSPrivilegeExtObjectCollection::getPrivilegeExtObject(
	JSC::ExecState* exec, const JSC::Identifier& iPropName, JSC::JSValue& valueOut)
{
	CEHResult hr = CE_SILK_ERR_OPERATION_FAILED;
	CEJSPrivilegeExtObjectDeclaration* declaration = 0;

	if( _owner == 0 )
	{
		return(CE_SILK_ERR_OPERATION_FAILED);
	}

	hr = _owner->getJSPrivilegeExtObjectDeclaration(exec, &declaration);
	if (CESucceeded(hr))
	{
		INT32 classId;
		UINT32 attr;
		hr = declaration->isDeclared(iPropName, &classId, &attr);
		if (CESucceeded(hr))
		{
			PrivilegeExtObjectKey key(classId);
			PrivilegeExtObjectEntry* pEntry = 0;
			if (!_privilegeExtObjectHash.find(key, pEntry))
			{
				pEntry = new PrivilegeExtObjectEntry(classId);
				if (pEntry)
				{
					hr = _privilegeExtObjectHash.insert(pEntry);
					if (CEFailed(hr))
					{
						delete pEntry;
						pEntry = 0;
					}
				}
				else
				{
					hr = CE_SILK_ERR_MEMERR;
				}
			}
			if (pEntry)
			{
				hr = pEntry->getObject(exec, _owner, valueOut);
			}
		}
	}
    return hr;
}

CEHResult CEJSPrivilegeExtObjectCollection::PrivilegeExtObjectEntry::getObject(
	JSC::ExecState* exec, JSExternal* owner, JSC::JSValue& valueOut)
{
	CEHResult hr = CE_S_OK;
	switch (_authStatus) {
	case CEJSAuthStatus_Authorized:
		valueOut = JSC::JSValue(_rObject);
		break;
	case CEJSAuthStatus_Unauthorized:
		valueOut = JSC::jsUndefined();
		break;
	case CEJSAuthStatus_UnauthorizedTemporarily:
		{
			CEComICEHtmlCredentialRef rCredential;
			hr = owner->getCredential(rCredential);
			if (CESucceeded(hr))
			{
				INT_PTR objectId = 0;
				hr = CEJSExternalAppCallback::authorizeOfPrivilegeExtObj(exec, _key.getClassId(), rCredential.object(), &_authStatus, &objectId);
				if (CESucceeded(hr) && _authStatus == CEJSAuthStatus_Authorized)
				{
					hr = JSPrivilegeExtObject::create(exec,objectId, &_rObject, owner);
					if (CESucceeded(hr))
					{
						valueOut = JSC::JSValue(_rObject);
					}
				}
			}
		}
		break;
	}
	return hr;
}
