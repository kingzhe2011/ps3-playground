/*
 * Copyright 2010 Sony Network Entertainment
 * All rights reserved
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND SONY NETWORK ENTERTAINMENT DISCLAIMS
 * ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL SONY NETWORK ENTERTAINMENT
 * BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef __PS3_COMPAT_SYS_SOCKET_H__
#define __PS3_COMPAT_SYS_SOCKET_H__

#include <include/sys/types.h>
#include <include/sys/socket.h>

#define EWOULDBLOCK     (EAGAIN)
#define EADDRINUSE      (-2)
#define EADDRNOTAVAIL   (-3)

#if defined(__cplusplus)
extern "C" {
#endif

int getsockerrno(void);
void setsockerrno(int err);
int closesocket(int fd);

#if defined(__cplusplus)
}
#endif

static inline int ps3_accept(int s, struct sockaddr * addr, socklen_t * addrlen)
{
	int result = accept(s, addr, addrlen);
	return (result < 0) ? -1 : result;
}

static inline int ps3_bind(int s, const struct sockaddr * addr, socklen_t addrlen)
{
	int result = bind(s, addr, addrlen);
	return (result < 0) ? -1 : result;
}

static inline int ps3_connect(int s, const struct sockaddr * name, socklen_t namelen)
{
	int result = connect(s, name, namelen);
	return (result < 0) ? -1 : result;
}

static inline int ps3_getpeername(int s, struct sockaddr * name, socklen_t * namelen)
{
	int result = getpeername(s, name, namelen);
	return (result < 0) ? -1 : result;
}

static inline int ps3_getsockname(int s, struct sockaddr * name, socklen_t * namelen)
{
	int result = getsockname(s, name, namelen);
	return (result < 0) ? -1 : result;
}

static inline int ps3_getsockopt(int s, int level, int optname, void * optval, socklen_t * optlen)
{
	int result = getsockopt(s, level, optname, optval, optlen);
	return (result < 0) ? -1 : result;
}

static inline int ps3_listen(int s, int backlog)
{
	int result = listen(s, backlog);
	return (result < 0) ? -1 : result;
}

static inline ssize_t ps3_recv(int s, void * buf, size_t len, int flags)
{
	ssize_t result = recv(s, buf, len, flags);
	return (result < 0) ? -1 : result;
}

static inline ssize_t ps3_recvfrom(int s, void * buf, size_t len, int flags, struct sockaddr * from, socklen_t * fromlen)
{
	ssize_t result = recvfrom(s, buf, len, flags, from, fromlen);
	return (result < 0) ? -1 : result;
}

static inline ssize_t ps3_recvmsg(int s, struct msghdr * msg, int flags)
{
	ssize_t result = recvmsg(s, msg, flags);
	return (result < 0) ? -1 : result;
}

static inline ssize_t ps3_send(int s, const void * msg, size_t len, int flags)
{
	ssize_t result = send(s, msg, len, flags);
	return (result < 0) ? -1 : result;
}

static inline ssize_t ps3_sendmsg(int s, const struct msghdr * msg, int flags)
{
	ssize_t result = sendmsg(s, msg, flags);
	return (result < 0) ? -1 : result;
}

static inline ssize_t ps3_sendto(int s, const void * msg, size_t len, int flags, const struct sockaddr *to, socklen_t tolen)
{
	ssize_t result = sendto(s, msg, len, flags, to, tolen);
	return (result < 0) ? -1 : result;
}

static inline int ps3_setsockopt(int s, int level, int optname, const void * optval, socklen_t optlen)
{
	int result = setsockopt(s, level, optname, optval, optlen);
	return (result < 0) ? -1 : result;
}

static inline int ps3_shutdown(int s, int how)
{
	int result = shutdown(s, how);
	return (result < 0) ? -1 : result;
}

static inline int ps3_socket(int domain, int type, int protocol)
{
	int result = socket(domain, type, protocol);
	return (result < 0) ? -1 : result;
}

static inline int ps3_socketclose(int s)
{
	int result = socketclose(s);
	return (result < 0) ? -1 : result;
}

#define accept      ps3_accept
#define bind        ps3_bind
#define connect     ps3_connect
#define getpeername ps3_getpeername
#define getsockname ps3_getsockname
#define getsockopt  ps3_getsockopt
#define listen      ps3_listen
#define recv        ps3_recv
#define recvfrom    ps3_recvfrom
#define recvmsg     ps3_recvmsg
#define send        ps3_send
#define sendmsg     ps3_sendmsg
#define sendto      ps3_sendto
#define setsockopt  ps3_setsockopt
#define shutdown    ps3_shutdown
#define socket      ps3_socket
#define socketclose ps3_socketclose

#endif /* __PS3_COMPAT_SYS_SOCKET_H__ */
