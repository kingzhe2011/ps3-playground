/*
 * Copyright 2010 Sony Network Entertainment
 * All rights reserved
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND SONY NETWORK ENTERTAINMENT DISCLAIMS
 * ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL SONY NETWORK ENTERTAINMENT
 * BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef __PS3_COMPAT_CTYPE_H__
#define __PS3_COMPAT_CTYPE_H__

#ifdef _STD_USING
#undef _STD_USING
#include <include/ctype.h>
#define _STD_USING
#else
#include <include/ctype.h>
#endif /* _STD_USING */

#if defined(__cplusplus)
using namespace std;
#endif

#endif /* __PS3_COMPAT_CTYPE_H__ */
